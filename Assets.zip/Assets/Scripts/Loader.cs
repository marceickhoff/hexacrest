﻿using UnityEngine;

public class Loader : MonoBehaviour {

	public GameObject manager;

	void Awake () {
		if (GameManager.instance == null) {
			Instantiate (manager);
		}
	}
}