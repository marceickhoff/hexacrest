﻿using System.Collections;
using System.Collections.Generic;
using Players;
using UnityEngine;
using World;

public class GameManager : MonoBehaviour {

	public static GameManager instance;
	public WorldController world;
	private List<PlayerController> _players;
	private int _currentPlayerIndex;
	private Hashtable _protocol;
	public Camera cam;

	public GameObject BuildDialog;

	void Start () {
		_players = GetPlayers();
		if (instance == null) {
			instance = this;
		}
		else if (instance != this) {
			Destroy(gameObject);
		}
		cam = GameObject.FindWithTag("MainCamera").GetComponent<Camera>();
		Instantiate(world);
		RollBeginner();
		RoundStart();
		BuildDialog = GameObject.Find("Canvas").transform.Find("BuildDialog").gameObject;
	}

	public void BuildPath() {
		var player = instance.GetCurrentPlayer() as HumanPlayer;
		player.HighlightTiles(4);
	}

	public void ShowBuildDialog() {
		BuildDialog.SetActive(true);
	}

	public void HideBuildDialog() {
		BuildDialog.SetActive(false);
	}

	public void RollBeginner() {
		foreach (var player in _players) {
			player.hasTurn = false;
		}
		_currentPlayerIndex = Random.Range(0, _players.Count);
		_players[_currentPlayerIndex].hasTurn = true;
	}

	public void RoundStart () {
		GetCurrentPlayer().RoundStart();
	}

	public void RoundEnd() {
		NextPlayer();
		RoundStart();
	}

	public void NextPlayer() {
		GetCurrentPlayer().hasTurn = false;
		_currentPlayerIndex++;
		if (_currentPlayerIndex >= _players.Count) {
			_currentPlayerIndex = 0;
		}
		GetCurrentPlayer().hasTurn = true;
	}

	public PlayerController GetCurrentPlayer() {
		return _players[_currentPlayerIndex];
	}

	public List<PlayerController> GetPlayers() {
		if (_players != null && _players.Count > 0) return _players;
		var playerGameObjects = GameObject.FindGameObjectsWithTag("Player");
		var players = new List<PlayerController>();
		foreach (var player in playerGameObjects) {
			players.Add(player.GetComponent<PlayerController>());
		}
		return players;
	}
}