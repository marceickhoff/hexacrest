﻿using UnityEngine;
using System.Collections.Generic;
using World;

public class WorldController : MonoBehaviour {
	public List<Tile> tiles = new List<Tile>();

	/// <summary>
	///   <para>Starts the world generator if one exists.</para>
	/// </summary>
	void Start() {
		var generator = GetComponent<Generator>();
		if (generator != null) {
			generator.Generate();
		}
	}

	/// <summary>
	///   <para>Returns a tile blueprint from this worlds tile list if it exists.</para>
	/// </summary>
	/// <param name="tileName">Tile name.</param>
	public Tile GetTile(string tileName) {
		return tiles.Find(t => t.name.Equals(tileName));
	}
}

