namespace Players {
	public class NetworkPlayer : PlayerController {

	}
}