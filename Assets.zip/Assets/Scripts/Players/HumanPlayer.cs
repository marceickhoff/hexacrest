using UnityEngine;
using World;

namespace Players {
	public class HumanPlayer : PlayerController {
		private TileController _activeTile;

		public void Click(RaycastHit target) {
			var clickedTile = target.transform.GetComponent<TileController>();
			if (clickedTile != null) {
				if (clickedTile.tile.Equals(GameManager.instance.world.GetTile("settlement"))) {
					if (GameManager.instance.GetCurrentPlayer().Equals(this) && clickedTile.owner.Equals(this)) {
						_activeTile = clickedTile;
						GameManager.instance.ShowBuildDialog();
					}
				}
				/*if (TileController.highlightedTiles != null && TileController.highlightedTiles.Contains(clickedTile)) {
					if (GameManager.instance.GetCurrentPlayer().Equals(this)) {*/
						BuildRoad(clickedTile);
						//TileController.UnHighlightAll();
					/*}
				}*/
			}
		}

		public void HighlightTiles(int radius) {
			GameManager.instance.HideBuildDialog();
			/*foreach (var tile in _activeTile.GetArea(radius)) {
				tile.Highlight();
			}*/
			_activeTile = null;
		}

		void Update() {
			if (Input.GetButtonUp("Fire1")) {
				var ray = GameManager.instance.cam.ScreenPointToRay (Input.mousePosition);
				RaycastHit hit;
				if (Physics.Raycast (ray, out hit)) {
					Click(hit);
				}
			}
		}
	}
}