namespace Players {
	public class AiPlayer : PlayerController {

	}
}