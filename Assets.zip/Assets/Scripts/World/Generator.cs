﻿using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace World {
	public class Generator : MonoBehaviour {
		
		public int size = 50;
		public int forestCount = 60;
		public int mountainCount = 20;
		public int lakeCount = 10;
		public string randomSeed;

		private List<TileController> _playerSpawns = new List<TileController>();
		private WorldController _world;

		/// <summary>
		///   <para>Generates a random world.</para>
		/// </summary>
		public void Generate() {
			_world = GetComponent<WorldController>();
			SetRandomSeed();
			CreateDeepOcean(size);
			var playerCount = GameManager.instance.GetPlayers().Count;
			CreateContinent(playerCount, _world.GetTile("meadow"));
			CreateForests(playerCount * forestCount, _world.GetTile("forest"), 0, 2);
			CreateLakes(playerCount * lakeCount, _world.GetTile("waterLake"),  0, 2);
			CreateMountains(playerCount * mountainCount, _world.GetTile("mountain"), 0, 2);
			ClearPaths();
			DistributeSoundSources("waterOceanShallow", 4);
			DistributeSoundSources("forest", 5);
			DistributeSoundSources("mountain", 4);
			foreach (var spawn in _playerSpawns) {
				PrepareSpawnArea(spawn);
			}
			//if (debugMode) TileController.DebugAnimate();
		}

		/// <summary>
		///   <para>Initializes the random number generator with the given seed.</para>
		/// </summary>
		public void SetRandomSeed() {
			if (randomSeed == null) randomSeed = "";
			if (randomSeed.Equals("")) {
				for (var i = 0; i < 8; i++) {
					randomSeed += Random.Range(0, 9);
				}
			}
			Random.InitState(randomSeed.GetHashCode());
		}

		/// <summary>
		///   <para>Creates a square ocean of the given size including outer static and inner non-static ocean.</para>
		/// </summary>
		/// <param name="oceanSize">Size of the inner non-static ocean.</param>
		private void CreateDeepOcean(int oceanSize) {
			var newTiles = new Queue<TileController>();
			var waterTile = _world.GetTile("waterOceanDeep");
			newTiles.Enqueue(TileController.Create(waterTile, Vector3.zero));
			while(newTiles.Count > 0) {
				var current = newTiles.Dequeue();
				if (Mathf.Abs(current.transform.position.x * 2) <= Tile.diameter * (oceanSize - 1) && Mathf.Abs(current.transform.position.z * 2) <= Tile.height * (oceanSize - 1)) {
					foreach (var direction in Direction.List()) {
						var pos = current.GetNeighborPositionAbsolute(direction);
						if (!current.HasNeighbor(direction)) {
							var created = TileController.Create(waterTile, pos);
							newTiles.Enqueue(created);
							/*if (Mathf.Abs(current.transform.position.x * 2) > Tile.diameter * (innerSize - 1) || Mathf.Abs(current.transform.position.z * 2) > Tile.height * (innerSize - 1)) {
								var meshRenderer = created.GetComponent<MeshRenderer>();
								meshRenderer.receiveShadows = false;
								meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
								meshRenderer.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
								Destroy(created.GetComponent<BoxCollider>());
								created.gameObject.isStatic = true;
							}*/
						}
					}
				}
			}
		}

		/// <summary>
		///   <para>Creates shallow oceans around land and makes deep ocean tiles static.</para>
		/// </summary>
		public void CreateShallowOceans() {
			//TODO: This slows down world generation significantly. Possible solution: Generate land first, then shallow ocean, then deep ocean.
			var oceanTiles = TileController.GetAll ("waterOceanDeep");
			var replaceTiles = new List<TileController> ();
			foreach (var tile in oceanTiles) {
				foreach (var neighbor in tile.GetNeighbors()) {
					if (!neighbor.name.Equals ("waterOceanDeep")) {
						foreach (var areaTile in tile.GetArea(10)) {
							if (areaTile.name.Equals("waterOceanDeep") && !replaceTiles.Contains (areaTile)) {
								replaceTiles.Add (areaTile);
							}
						}
					}
				}
			}
			foreach (var tile in replaceTiles) {
				TileController.Replace (tile, _world.GetTile("waterOceanShallow"));
			}
			foreach (var tile in TileController.GetAll("waterOceanDeep")) {
				// Make static and and increase performance
				var meshRenderer = tile.GetComponent<MeshRenderer>();
				meshRenderer.receiveShadows = false;
				meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
				meshRenderer.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
				Destroy(tile.GetComponent<BoxCollider>());
				tile.gameObject.isStatic = true;
			}
		}

		/// <summary>
		///   <para>Creates a natural looking continent fit for the given player count.</para>
		/// </summary>
		/// <param name="playerCount">Player count.</param>
		/// <param name="paint">Tile to draw continent with.</param>
		private void CreateContinent(int playerCount, Tile paint) {
			TileController.Replace(TileController.GetOrigin(), _world.GetTile("meadow")); //Origin
			var playerDirections = Direction.Spread(playerCount);
			var paths = new List<TileController>();
			var playerNumber = 0;
			var createdTiles = new List<TileController>();
			foreach (var direction in playerDirections) {
				paths.AddRange(DrawSquigglyLine(TileController.GetOrigin(), _world.GetTile("meadow"), new List<string> {
						"waterOceanDeep",
						"meadow"
					},  direction, size / 4 + Mathf.RoundToInt(Mathf.Pow(playerCount, 1.5f))));
				var spawnTile = TileController.Replace(TileController.GetLast(), _world.GetTile("settlement"));
				spawnTile.owner = GameManager.instance.GetPlayers()[playerNumber];
				_playerSpawns.Add(spawnTile);
				playerNumber++;
			}
			foreach (var t in paths) {
				DrawLand(t, paint, Random.Range(1, 20), .1f);
			}
			//CreateShallowOceans (); // Disabled for now to increase generation speed.
		}

		/// <summary>
		///   <para>Creates random forests.</para>
		/// </summary>
		/// <param name="count">Forest count.</param>
		/// <param name="paint">Tile to draw forest with.</param>
		/// <param name="sizeMin">Minimum size.</param>
		/// <param name="sizeMax">Maximum size.</param>
		private void CreateForests(int count, Tile paint, int sizeMin, int sizeMax) {
			int index;
			var tiles = TileController.GetAll("meadow");
			for (int i = 0; i <= count; i++) {
				index = Random.Range(0, tiles.Count);
				var start = tiles[index];
				var lineTileControllers = DrawSquigglyLine(start, paint, new List<string> {
					"meadow",
					"forest"
				}, Direction.Random(), 5);
				foreach (var tile in lineTileControllers) {
					var size = Random.Range(sizeMin, sizeMax + 1);
					DrawCircle(tile, paint, new List<string> {
						"meadow",
						"forest"
					}, size, .33f);
				}
			}
		}

		/// <summary>
		///   <para>Creates random lakes.</para>
		/// </summary>
		/// <param name="count">Lake count.</param>
		/// <param name="paint">Tile to draw lakes with.</param>
		/// <param name="sizeMin">Minimum thickness.</param>
		/// <param name="sizeMax">Maximum thickness.</param>
		private void CreateLakes(int count, Tile paint, int sizeMin, int sizeMax) {
			var canvas = new List<string> {
				"meadow",
				"forest",
				"waterLake"
			};
			var tiles = TileController.GetAll(canvas);
			for (int i = 0; i <= count; i++) {
				var index = Random.Range(0, tiles.Count);
				var start = tiles[index];
				var lineTileControllers = DrawSquigglyLine(start, paint, canvas, Direction.Random(), 3);
				foreach (var tile in lineTileControllers) {
					DrawCircle(tile, paint, canvas, Random.Range(sizeMin, sizeMax), .33f);
				}
			}
		}

		/// <summary>
		///   <para>Creates random mountain ranges.</para>
		/// </summary>
		/// <param name="count">Mountain range count.</param>
		/// <param name="paint">Tile to draw mountains with.</param>
		/// <param name="sizeMin">Minimum thickness.</param>
		/// <param name="sizeMax">Maximum thickness.</param>
		private void CreateMountains(int count, Tile paint, int sizeMin, int sizeMax) {
			int index;
			var canvas = new List<string> {
				"meadow",
				"forest",
				"mountain"
			};
			var tiles = TileController.GetAll(canvas);
			for (int i = 0; i <= count; i++) {
				index = Random.Range(0, tiles.Count);
				var start = tiles[index];
				var lineTileControllers = DrawSquigglyLine(start, paint, canvas, Direction.Random(), 5);
				foreach (var tile in lineTileControllers) {
					DrawCircle(tile, paint, canvas, Random.Range(sizeMin, sizeMax), .33f);
				}
			}
		}

		/// <summary>
		///   <para>Uses pathfinding to ensure a connection between all players. If no path exists, then it will create one by force.</para>
		/// </summary>
		private void ClearPaths() {
			var pathfinder = new Pathfinder();
			var connections = new List<HashSet<TileController>>();
			var lastSpawn = _playerSpawns[0];
			for (int i = 1; i < _playerSpawns.Count; i++) {
				var connection = new HashSet<TileController>();
				connection.Add(lastSpawn);
				connection.Add(_playerSpawns[i]);
				lastSpawn = _playerSpawns[i];
				connections.Add(connection);
			}
			foreach (var connection in connections) {
				var tiles = new List<TileController>();
				foreach (var tile in connection) {
					tiles.Add(tile);
				}

				var accessibleTileTypes = new List<string> {
					"meadow",
					"forest",
					"village"
				};
				var path = pathfinder.GetPath(tiles[0], tiles[1], TileController.GetAll(accessibleTileTypes));
				if (path.Count == 0) {
					var blockedTileTypes = new List<string> {
						"mountain",
						"waterLake",
						"waterOceanShallow",
						"waterOceanDeep"
					};
					accessibleTileTypes.AddRange(blockedTileTypes);
					path = pathfinder.GetPath(tiles[0], tiles[1], TileController.GetAll(accessibleTileTypes));
					foreach (var tileController in path) {
						if (!blockedTileTypes.Contains(tileController.tile.name)) continue;
						var adjacentMeadowCount = 0;
						var adjacentForestCount = 0;
						foreach (var neighbor in tileController.GetNeighbors()) {
							if (neighbor.tile.name.Equals("meadow")) adjacentMeadowCount++;
							if (neighbor.tile.name.Equals("forest")) adjacentForestCount++;
						}
						if (adjacentForestCount > adjacentMeadowCount) {
							TileController.Replace(tileController, _world.GetTile("forest"));
						}
						else {
							TileController.Replace(tileController, _world.GetTile("meadow"));
						}
					}
				}
				/*if (debugMode) {
					foreach (var tile in path) {
						var debug = TileController.SetTile(debugTileController, tile.transform.position + new Vector3(0,.5f,0));
						debug.transform.localScale = debug.transform.localScale * .25f;
					}
				}*/
			}
		}

		/// <summary>
		///   <para>Makes sure the given spawn area is fair and has access to all resources.</para>
		/// </summary>
		/// <param name="spawn">Spawn tile (probably a settlement).</param>
		private void PrepareSpawnArea(TileController spawn) {
			//TODO PrepareSpawnArea
		}

		/// <summary>
		///   <para>Distributes sound sources of all sound-enabled tiles evenly across the world.</para>
		/// </summary>
		/// <param name="tileType">Tile type.</param>
		/// <param name="distance">Minimum distance between sound sources of the given tile type.</param>
		private void DistributeSoundSources(string tileType, int distance) {
			foreach (var tile in TileController.GetAll(tileType)) {
				if (tile.tile.sound == null) continue;
				var allowSound = true;
				var middleOfTheOcean = true;


				//Start harcode for only doing shore tiles if ocean
				if (tileType.Contains("water")) {
					var nearLand = false;
					foreach (var neighbor in tile.GetNeighbors()) {
						if (!neighbor.name.Equals(tileType)) {
							nearLand = true;
						}
					}
					if (!nearLand) continue;
				}
				//End hardcode


				foreach (var areaTile in tile.GetArea(distance)) {
					if (areaTile.GetComponentInChildren<AudioSource>() != null) {
						allowSound = false;
					}
					if (!areaTile.tile.name.Contains("water")) {
						middleOfTheOcean = false;
					}
				}
				if (allowSound && !middleOfTheOcean && tile.tile.sound != null) {
					var sound = Instantiate(tile.tile.sound);
					sound.transform.parent = tile.transform;
					sound.time = Random.Range(0, sound.clip.length);
					sound.transform.position = tile.transform.position;
				}
			}
		}

		/// <summary>
		///   <para>Draws a squiggly line into a specific direction.</para>
		/// </summary>
		/// <param name="start">Start tile.</param>
		/// <param name="paint">Tile to draw line with.</param>
		/// <param name="canvas">Tile types on which the line can be drawn.</param>
		/// <param name="direction">Direction of the line.</param>
		/// <param name="length">Length of the line.</param>
		List<TileController> DrawSquigglyLine(TileController start, Tile paint, List<string> canvas, Direction direction, int length) {
			List<TileController> tiles = new List<TileController>();
			Direction randomDirection;
			while (length > 0) {
				randomDirection = direction.Near()[Random.Range(0, direction.Near().Count)];
				var neighbor = start.GetNeighbor(randomDirection);
				if (neighbor != null && canvas.Contains(neighbor.tile.name) && !tiles.Contains(neighbor)) {
					tiles.Add(TileController.Replace(neighbor, paint));
					start = TileController.GetLast();
				}
				else break;
				length--;
			}
			return tiles;
		} List<TileController> DrawSquigglyLine(TileController start, Tile paint, string canvas, Direction direction, int length) {
			return DrawSquigglyLine(start, paint, new List<string> {canvas}, direction, length);
		}

		/// <summary>
		///   <para>Replaces adjacent tiles.</para>
		/// </summary>
		/// <param name="tiles">Tiles to replace the neighbors of.</param>
		/// <param name="paint">Replacement.</param>
		/// <param name="canvas">Tile types which can be replaced.</param>
		/// <param name="density">Randomly skip tiles [0..1] (0 = skip all, 1 = skip none).</param>
		List<TileController> DrawNeighbors(List<TileController> tiles, Tile paint, List<string> canvas, float density) {
			List<TileController> newTiles = new List<TileController>();
			foreach (var tile in tiles) {
				foreach (var direction in Direction.List()) {
					var neighbor = tile.GetNeighbor(direction);
					if (neighbor != null && canvas.Contains(neighbor.tile.name) && Random.value <= density) {
						newTiles.Add(TileController.Replace(neighbor, paint));
					}
				}
			}
			return newTiles;
		} List<TileController> DrawNeighbors(List<TileController> tiles, Tile paint, string canvas, float density) {
			return DrawNeighbors(tiles, paint, new List<string> {canvas}, density);
		} List<TileController> DrawNeighbors(TileController tiles, Tile paint, List<string> canvas, float density) {
			return DrawNeighbors(new List<TileController> {tiles}, paint, canvas, density);
		} List<TileController> DrawNeighbors(TileController tiles, Tile paint, string canvas, float density) {
			return DrawNeighbors(new List<TileController> {tiles}, paint, canvas, density);
		}

		/// <summary>
		///   <para>Draws a, well, technically more of a hexagon, of the given radius.</para>
		/// </summary>
		/// <param name="center">Center tile.</param>
		/// <param name="paint">Tile to draw circle with.</param>
		/// <param name="canvas">Tile types on which the circle can be drawn.</param>
		/// <param name="radius">Radius.</param>
		/// <param name="density">Randomly skip tiles [0..1] (0 = skip all, 1 = skip none).</param>
		List<TileController> DrawCircle(TileController center, Tile paint, List<string> canvas, int radius, float density) {
			List<TileController> tiles = new List<TileController>();
			List<TileController> newTiles = new List<TileController>();
			newTiles.Add(center);
			tiles.AddRange(newTiles);
			for (var i = 0; i < radius; i++) {
				newTiles = DrawNeighbors(newTiles, paint, canvas, density);
				tiles.AddRange(newTiles);
			}
			return tiles;
		} List<TileController> DrawCircle(TileController center, Tile paint, string canvas, int radius, float density) {
			return DrawCircle(center, paint, new List<string> {canvas}, radius, density);
		}

		/// <summary>
		///   <para>Draws a natural-looking land around a given origin tile.</para>
		/// </summary>
		/// <param name="origin">Origin tile.</param>
		/// <param name="paint">Tile to draw land with.</param>
		/// <param name="radius">Approximate radius.</param>
		/// <param name="breakProbability">Randomly stop drawing [0..1] (0 = never stop, 1 = stop immediately). This makes the land look more natural and can cause bays and peninsulas.</param>
		List<TileController> DrawLand(TileController origin, Tile paint, int radius, float breakProbability) {
			radius--;
			var tiles = new List<TileController>();
			if (Random.value <= breakProbability) {
				return tiles;
			}
			foreach (var direction in Direction.List()) {
				if (origin.HasNeighbor(direction) && origin.GetNeighbor(direction).tile.name.Contains("water")) {
					tiles.Add(TileController.Replace(origin.GetNeighbor(direction), paint));
				}
			}
			if (radius > 0) {
				foreach (var tile in tiles) {
					DrawLand(tile, paint, radius, breakProbability);
				}
			}
			return tiles;
		}
	}
}
