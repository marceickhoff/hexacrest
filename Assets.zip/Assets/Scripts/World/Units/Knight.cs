using World;

namespace UnityEngine {
	public class Knight : Unit {

	}
}