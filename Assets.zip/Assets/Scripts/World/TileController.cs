﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

namespace World {
	public class TileController : MonoBehaviour {
		private static TileController _last;
		private static TileController _origin;
		private static Hashtable _all = new Hashtable();
		public static List<TileController> highlightedTiles = new List<TileController>();

		public Tile tile;
		public PlayerController owner;

		private bool _isRoad; //This does not mean that roads are visible, merely that this tile acts as if it were a road (i.e. transfers resources etc.). It may still be obstructed to units.
		private Hashtable _roads = new Hashtable(); //This is about actually visible road decals.

		/// <summary>
		///   <para>Creates a new tile at the specified world coordinates.</para>
		/// </summary>
		/// <param name="paint">Tile to create.</param>
		/// <param name="position">Global position.</param>
		/// <param name="tileType">Tile type this tile will be associated with.</param>
		/// <param name="index">New tile's position in the associated tile type's list.</param>
		public static TileController Create(Tile paint, Vector3 position, string tileType, int index) {
			var newInstance = Instantiate(paint.SelectRandomModel());
			_last = newInstance.AddComponent<TileController>();
			var tileCollider = newInstance.AddComponent<MeshCollider>();
			tileCollider.convex = true;
			_last.tile = paint;
			_last.transform.position = position;
			_last.transform.rotation = Quaternion.Euler(0f, Random.Range(0, 6) % 6 * 60f, 0f);
			//_last.transform.parent = transform;
			_last.name = tileType;
			if (!_all.ContainsKey(tileType)) {
				_all.Add(tileType, new List<TileController>());
			}
			if (_all[tileType].GetType() == typeof(List<TileController>)) {
				var list = _all[tileType] as List<TileController>;
				if (list != null) list.Insert(index, _last);
			}
			if (_origin == null) _origin = _last;
			return _last;
		}

		/// <summary>
		///   <para>Creates a new tile at the specified world coordinates.</para>
		/// </summary>
		/// <param name="paint">Tile to create.</param>
		/// <param name="position">Global position.</param>
		/// <param name="index">New tile's position in the associated tile type's list.</param>
		public static TileController Create(Tile paint, Vector3 position, int index) {
			return Create(paint, position, paint.name, index);
		}

		/// <summary>
		///   <para>Creates a new tile at the specified world coordinates.</para>
		/// </summary>
		/// <param name="paint">Tile to create.</param>
		/// <param name="position">Global position.</param>
		/// <param name="tileType">Tile type this tile will be associated with.</param>
		public static TileController Create(Tile paint, Vector3 position, string tileType) {
			return Create(paint, position, tileType, GetAll(paint.name).Count);
		}

		/// <summary>
		///   <para>Creates a new tile at the specified world coordinates.</para>
		/// </summary>
		/// <param name="paint">Tile to create.</param>
		/// <param name="position">Global position.</param>
		public static TileController Create(Tile paint, Vector3 position) {
			return Create(paint, position, paint.name);
		}

		/// <summary>
		///   <para>Replaces an existing tile.</para>
		/// </summary>
		/// <param name="original">Original tile controller.</param>
		/// <param name="replacement">Replacement tile.</param>
		/// <param name="tileType"></param>
		public static TileController Replace(TileController original, Tile replacement, string tileType) {
			if (!original.isActiveAndEnabled) return _last;
			if (original.name == replacement.name) {
				_last = Create(replacement, original.transform.position, tileType, GetAll(original.name).FindIndex(tc => tc.name.Equals(original.name)));
			}
			else {
				var list = _all[original.name] as List<TileController>;
				_all.Remove(original.name);
				if (list != null) list.Remove(original);
				_all.Add(original.name, list);
				_last = Create(replacement, original.transform.position, tileType);
			}
			//_last.transform.parent = transform;
			_last.name = tileType;
			if (original.Equals(_origin)) _origin = _last;
			original.gameObject.SetActive(false);
			Destroy(original.gameObject);
			return _last;
		}

		/// <summary>
		///   <para>Replaces an existing tile.</para>
		/// </summary>
		/// <param name="original">Original tile controller.</param>
		/// <param name="replacement">Replacement tile.</param>
		public static TileController Replace(TileController original, Tile replacement) {
			return Replace(original, replacement, replacement.name);
		}

		/// <summary>
		///   <para>Returns a list of all existing tile controllers in this world.</para>
		/// </summary>
		public static List<TileController> GetAll() {
			var all = new List<TileController>();
			foreach (var list in _all) {
				if (list.GetType() == typeof(List<TileController>)) {
					var l = list as List<TileController>;
					if (l != null) all.AddRange(l);
				}
			}
			return all;
		}

		/// <summary>
		///   <para>Returns a list of all existing tile controllers in this world that match a specified tile type.</para>
		/// </summary>
		/// <param name="tileType">Tile type.</param>
		public static List<TileController> GetAll(string tileType) {
			var all = new List<TileController>();
			if (_all.ContainsKey(tileType) && _all[tileType].GetType() == typeof(List<TileController>)) {
				all =_all[tileType] as List<TileController>;
			}
			return all;
		}

		/// <summary>
		///   <para>Returns a list of all existing tile controllers in this world that match the specified tile types.</para>
		/// </summary>
		/// <param name="tileTypes">Tile types.</param>
		public static List<TileController> GetAll(IEnumerable<string> tileTypes) {
			var all = new List<TileController>();
			foreach (var tileType in tileTypes) {
				all.AddRange(GetAll(tileType));
			}
			return all;
		}

		/// <summary>
		///   <para>Returns the last created or changed tile.</para>
		/// </summary>
		public static TileController GetLast() {
			return _last;
		}

		/// <summary>
		///   <para>Returns the first ever created tile (should be located at Vector3.zero).</para>
		/// </summary>
		public static TileController GetOrigin() {
			return _origin;
		}

		/// <summary>
		///   <para>Checks if there are any neighboring tiles.</para>
		/// </summary>
		public bool HasNeighbor() {
			return GetNeighbors().Count > 0;
		}

		/// <summary>
		///   <para>Checks if there is a neighboring tile in the specified direction.</para>
		/// </summary>
		/// <param name="direction"></param>
		public bool HasNeighbor(Direction direction) {
			return GetNeighbor(direction) != null;
		}

		/// <summary>
		///   <para>Gets the local position of a potential neighboring tile in the specified direction.</para>
		/// </summary>
		/// <param name="direction"></param>
		public Vector3 GetNeighborPosition(Direction direction) {
			return direction.vector;
		}

		/// <summary>
		///   <para>Gets the world position of a potential neighboring tile in the specified direction.</para>
		/// </summary>
		/// <param name="direction"></param>
		public Vector3 GetNeighborPositionAbsolute(Direction direction) {
			return gameObject.transform.position + direction.vector;
		}

		/// <summary>
		///   <para>Gets the neighboring tile controller in the specified direction if it exists. Uses ray casting to detect tiles.</para>
		/// </summary>
		/// <param name="direction"></param>
		public TileController GetNeighbor(Direction direction) {
			var center = gameObject.transform.position;
			var rayVector = GetNeighborPosition(direction);
			RaycastHit hit;
			return Physics.Raycast(center, rayVector, out hit, Tile.diameter) ? hit.transform.gameObject.GetComponent<TileController>() : null;
		}

		/// <summary>
		///   <para>Gets all neighboring tile controllers. Uses ray casting to detect tiles.</para>
		/// </summary>
		public List<TileController> GetNeighbors() {
			var neighbors = new List<TileController>();
			foreach (var direction in Direction.List()) {
				if (HasNeighbor(direction)) {
					neighbors.Add(GetNeighbor(direction));
				}
			}
			return neighbors;
		}

		/// <summary>
		///   <para>Gets all tile controllers in a specified radius.</para>
		/// </summary>
		/// <param name="radius">Radius.</param>
		/// <param name="filters">Tile type filters.</param>
		public List<TileController> GetArea(int radius, string[] filters) {
			if (radius == 1) return GetNeighbors();
			var totalStackSize = 1;
			for (var i = 1; i < radius; i++) {
				totalStackSize += Mathf.RoundToInt(Mathf.Pow(0, i) + 6 * i);
			}
			var area = new List<TileController>();
			var frontier = new Queue<TileController>();
			frontier.Enqueue(this);
			while (frontier.Count > 0 && totalStackSize > 0) {
				var current = frontier.Dequeue();
				var neighbors = current.GetNeighbors();
				foreach (var next in neighbors) {
					if (!area.Contains(next)) {
						frontier.Enqueue(next);
						area.Add(next);
						totalStackSize--;
					}
				}
			}
			area.Add(this); //Adding center piece
			if (filters.Length > 0) {
				foreach (var tileController in area) {
					if (!filters.Contains(tileController.name)) {
						area.Remove(tileController);
					}
				}
			}
			return area;
		}

		/// <summary>
		///   <para>Gets all tile controllers in a specified radius.</para>
		/// </summary>
		/// <param name="radius">Radius.</param>
		/// <param name="filter">Tile type filter.</param>
		public List<TileController> GetArea(int radius, string filter) {
			return GetArea(radius, new[] {filter});
		}

		/// <summary>
		///   <para>Gets all tile controllers in a specified radius.</para>
		/// </summary>
		/// <param name="radius">Radius.</param>
		public List<TileController> GetArea(int radius) {
			return GetArea(radius, new string[] {});
		}

		/// <summary>
		///   <para>Changes this tiles model.</para>
		/// </summary>
		/// <param name="newModel">New model.</param>
		public void ChangeModel(GameObject newModel) {
			var mesh = gameObject.GetComponent<MeshFilter>().mesh = newModel.GetComponent<MeshFilter>().sharedMesh;
			gameObject.GetComponent<MeshRenderer>().materials = newModel.GetComponent<MeshRenderer>().sharedMaterials;
			gameObject.GetComponent<MeshCollider>().sharedMesh = mesh;
		}

		/// <summary>
		///   <para>Updates road decals on tile according to neighboring tiles.</para>
		/// </summary>
		public void UpdateRoadDecals() {
			foreach (var roadDecal in _roads) {
				if (roadDecal is GameObject) {
					var decal = roadDecal as GameObject;
					decal.SetActive(false);
				}
			}
			if (_isRoad) {
				if (tile.roadModels.Length > 0) {
					ChangeModel(tile.SelectRandomRoadModel());
				}
				foreach (var direction in Direction.List()) {
					if (HasNeighbor(direction) && (GetNeighbor(direction)._isRoad || GetNeighbor(direction).tile.passesResources)) {
						if (_roads.ContainsKey(direction)) {
							var road = _roads[direction] as GameObject;
							if (road != null) road.SetActive(true);
						}
						else if (tile.roadDecals.Length > 0) {
							var road = Instantiate(tile.SelectRandomRoadDecal());
							road.transform.position = new Vector3(transform.position.x, .25f, transform.position.z);
							road.transform.rotation = direction.Opposite().Angle();
							road.transform.parent = transform;
							_roads.Add(direction, road);
						}
					}
				}
			}
		}

		/// <summary>
		///   <para>Adds or removes a road on this tile.</para>
		/// </summary>
		/// <param name="hasRoad">Enable or disable road.</param>
		public void SetRoad(bool hasRoad) {
			_isRoad = hasRoad;
			UpdateRoadDecals();
			foreach (var neighbor in GetNeighbors()) {
				neighbor.UpdateRoadDecals();
			}
		}

		/// <summary>
		///   <para>Checks if this tile is a road.</para>
		/// </summary>
		public bool IsRoad() {
			return _isRoad;
		}

		/// <summary>
		///   <para>Highlights this tile visually.</para>
		/// </summary>
		public void Highlight() {
			highlightedTiles.Add(this);
			var mesh = gameObject.GetComponent<MeshRenderer>();
			mesh.materials[1].color = new Color(mesh.materials[1].color.r + .05f, mesh.materials[1].color.g + .05f, mesh.materials[1].color.b + .05f);
		}

		/// <summary>
		///   <para>Un-highlights all tiles.</para>
		/// </summary>
		public static void UnHighlightAll() {
			foreach (var tile in highlightedTiles) {
				var mesh = tile.GetComponent<MeshRenderer>();
				mesh.materials[1].color = new Color(mesh.materials[1].color.r - .05f, mesh.materials[1].color.g - .05f, mesh.materials[1].color.b - .05f);
			}
			highlightedTiles.Clear();
		}
	}
}
