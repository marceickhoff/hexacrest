﻿using UnityEditor;
using UnityEngine;

namespace World {

	[CreateAssetMenu(fileName = "New Tile", menuName = "Tile")]
	public class Tile : ScriptableObject {

		public GameObject[] models;
		public GameObject[] destroyedModels;
		public GameObject[] roadModels;
		public GameObject[] roadDecals;

		public static readonly float diameter = 1;
		public static readonly float height = diameter * Mathf.Sin(60 * Mathf.PI / 180);

		public AudioSource sound;

		public bool isWalkable;
		public bool isStructure;
		public bool passesResources;
		public int controlRadius = 0;

		/// <summary>
		///   <para>Checks if a tile can be accessed by a player.</para>
		/// </summary>
		public bool IsAccessible() {
			return isWalkable || roadDecals.Length > 0;
		}

		/// <summary>
		///   <para>Returns a random 3D model from the destroyed tile model list.</para>
		/// </summary>
		public GameObject SelectRandomDestroyedModel() {
			return destroyedModels[Random.Range(0, destroyedModels.Length)];
		}

		/// <summary>
		///   <para>Returns a random 3D model from the road tile model list.</para>
		/// </summary>
		public GameObject SelectRandomRoadModel() {
			return roadModels[Random.Range(0, roadModels.Length)];
		}

		/// <summary>
		///   <para>Returns a random road decal from the road decal list.</para>
		/// </summary>
		public GameObject SelectRandomRoadDecal() {
			return roadDecals[Random.Range(0, roadDecals.Length)];
		}

		/// <summary>
		///   <para>Returns a random 3D model from the tiles model list.</para>
		/// </summary>
		public GameObject SelectRandomModel() {
			return models[Random.Range(0, models.Length)];
		}

		/// <summary>
		///   <para>Finds a tile in the database by file name.</para>
		/// </summary>
		/// <param name="name"></param>
		public static Tile Find(string name) {
			return AssetDatabase.LoadAssetAtPath<Tile>("Assets/Tiles/" + name + ".asset");
		}
	}
}