﻿namespace World.Tiles {
	public class Meadow : Tile {
	}
}
