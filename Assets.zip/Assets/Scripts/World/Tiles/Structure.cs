namespace World.Tiles {
	public class Structure : Tile {

	}
}