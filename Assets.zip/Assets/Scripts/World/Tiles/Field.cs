﻿namespace World.Tiles {
	public class Field : Tile {
	}
}
