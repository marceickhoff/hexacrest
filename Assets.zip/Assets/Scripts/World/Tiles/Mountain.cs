﻿namespace World.Tiles {
	public class Mountain : Tile {
	}
}
