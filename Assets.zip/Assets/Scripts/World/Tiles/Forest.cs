﻿namespace World.Tiles {
	public class Forest : Tile {
	}
}
