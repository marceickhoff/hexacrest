﻿namespace World.Tiles {
	public class Settlement : Tile {
	}
}
