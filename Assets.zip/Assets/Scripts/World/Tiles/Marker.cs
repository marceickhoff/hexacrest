﻿namespace World.Tiles {
	public class Marker : Tile {
	}
}
