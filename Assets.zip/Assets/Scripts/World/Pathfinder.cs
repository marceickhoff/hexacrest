using System.Collections.Generic;

namespace World {
	public class Pathfinder {
		public List<TileController> GetPath(TileController origin, TileController target, List<TileController> tileList) {
			var path = new List<TileController>();
			var frontier = new Queue<TileController>();
			frontier.Enqueue(origin);

			IDictionary<TileController, TileController> last = new Dictionary<TileController, TileController>();
			last[origin] = null;

			while (frontier.Count > 0) {
				var current = frontier.Dequeue();
				if (current == target) {
					while (!current.Equals(origin)) {
						path.Add(current);
						current = last[current];
					}
					path.Add(origin);
					break;
				}
				foreach (var next in current.GetNeighbors()) {
					if (!next.tile.IsAccessible() || last.ContainsKey(next)) continue;
					frontier.Enqueue(next);
					last[next] = current;
				}
			}
			return path;
		}
	}
}