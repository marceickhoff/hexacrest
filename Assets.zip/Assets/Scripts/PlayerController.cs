using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using World;
using World.Tiles;

public abstract class PlayerController : MonoBehaviour {
	private List<Structure> _ownedStructures;
	private List<Unit> _ownedUnits;
	private Hashtable _protocol; //"undo stack"
	public bool hasTurn = false;

	public List<Structure> GetOwnedStructures() {
		return _ownedStructures;
	}

	public List<Unit> GetOwnedUnits() {
		return _ownedUnits;
	}

	public void RoundStart() {
		//Debug.Log("Hi! I'm player "+name+" and it's my turn! Let's do this!");
	}

	public void Build(Structure structure, TileController position) {
		if (!hasTurn) return;
		_ownedStructures.Add(structure);
	}

	public void BuildRoad(TileController tile) {
		tile.SetRoad(true);
	}

	public void Spawn(Unit unit, TileController position) {
		if (!hasTurn) return;
		_ownedUnits.Add(unit);
	}

	public void Destroy(Structure structure) {
		if (!hasTurn) return;
		_ownedStructures.Remove(structure);
	}

	public void Kill(Unit unit, int amount) {
		if (!hasTurn) return;
		_ownedUnits.Remove(unit);
	}

	public void GainStructure(Structure structure) {
		_ownedStructures.Add(structure);
	}

	public void LoseStructure(Structure structure) {
		_ownedStructures.Remove(structure);
	}

	public void Move(Unit unit, TileController target) {
		if (!hasTurn) return;
		if (unit.Move(target)) {
			/*_protocol.Add(something);
			if (target contains enemy unit) {
				unit.Attack(enemy unit);
				if (!unit.IsAlive()) return;
			}
			if (target is owned by enemy player) {
				destroy or conquer structure
			}*/
		}
	}

	public void Undo() {
		if (!hasTurn) return;
	}

	public void Done() {
		if (!hasTurn) return;
		//send protocol to game manager, then:
		_protocol.Clear();
		GameManager.instance.RoundEnd();
	}

	public void Win() {
		//Won the game
	}

	public void Surrender() {
		if (!hasTurn) return;
		//Quit the game
	}

	public void Lose() {
		//Lost the game
	}
}